import formidable from 'formidable';
export const config = {api: {bodyParser:false}};
export default async function handler(req,res){
  const form=new formidable.IncomingForm();
  form.parse(req, async(err, fields, files)=>{
    if(err) return res.status(500).json({message:err.message});
    // Use GOOGLE_CLIENT_ID / SECRET / REFRESH_TOKEN to upload file to Drive
    res.status(200).json({message:`File "${files.file.name}" uploaded to Google Drive (simulated)`});
  });
}
