export default async function handler(req,res){
  if(req.method!=='POST'){res.status(405).json({error:'Method not allowed'});return;}
  let body=await new Promise(r=>{let d='';req.on('data',c=>d+=c);req.on('end',()=>r(d));});
  body=JSON.parse(body);
  console.log('AI prompt:',body.prompt);
  res.status(200).json({response:'This is a placeholder response from Gemini AI.'});
}
